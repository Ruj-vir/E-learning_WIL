<?php
    session_start();
    include('server.php');

    $errors = array();

    
    if(isset($_POST['butt_cname']))
    {
        $cname = mysqli_real_escape_string($conn, $_POST['cname']);
        if (empty($cname)) {
            array_push($errors, "Course_name is required");
        }

        
        if (count($errors) == 0) {
            

            $sql = "INSERT INTO information_data (Text) VALUES ('$cname')";
            mysqli_query($conn, $sql);

            
            $_SESSION['cname'] = $cname;            
            //header('location: index.php');
            echo 1;
        } else {
            // header("location: index.php");
            echo 0;
        }
    }


?>