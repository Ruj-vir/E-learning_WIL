<?php 

    $servername = "localhost";
    $username = "root";
    $password = "iTdev#2020";
    $dbname = "1_Approval_course";

    // Create Connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed" . mysqli_connect_error());
    } 

?>