              </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted"></div>
                            <div class="text-muted">&copy; 2020 - Thai Daizo Aerosol Co.Ltd (Thailand) | By : IT Section</div>
                        </div>
                    </div>
                </footer>
              </div>
			</div>
			
        <script src="assets/js/font-awesome.min.js" crossorigin="anonymous"></script>
        <script src="assets/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="assets/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="assets/js/bootstrap-3-typeahead.min.js" crossorigin="anonymous"></script>

        <script src="assets/js/scripts.js"></script>

    </body>
</html>

<?php //sqlsrv_close($conn); ?>