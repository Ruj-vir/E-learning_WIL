
        <script src="../assets/js/font-awesome.min.js" crossorigin="anonymous"></script>
        <script src="../assets/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="../assets/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../assets/js/scripts.js"></script>

    </body>
</html>

		<?php //sqlsrv_close($conn); ?>