<?php
	$SesUserID = $_SESSION['UserID_OT'];
	$SesState = $_SESSION['Status_OT'];
	$SesAuthor = $_SESSION['Authorize_OT'];

	if(isset($SesUserID) == NULL){
		echo "<script type=text/javascript>window.location='../index.php';</script>";
		exit();
	}
	if(isset($SesState) != "1"){
		echo "<script type=text/javascript>window.location='../index.php';</script>";
		exit();
	}
	if(!$SesAuthor){
		echo "<script type=text/javascript>window.location='../index.php';</script>";
		exit();
	}
?>
