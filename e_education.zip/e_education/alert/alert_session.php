<?php
  session_start();
  ini_set('display_errors', 0);
  error_reporting(~0);
  error_reporting (E_ALL ^ E_NOTICE);
  date_default_timezone_set('asia/bangkok');
?>
