function toggle() {

    if (document.getElementById("exampleCheck1").checked) {
        document.getElementById("myDIV").style.display = "block";
    } else {
        document.getElementById("myDIV").style.display = "none";
    }
  }