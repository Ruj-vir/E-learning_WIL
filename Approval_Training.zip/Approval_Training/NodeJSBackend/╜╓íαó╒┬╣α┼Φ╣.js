const express = require('express')
const app = express()
app.get('/',(req,res)=>{

})
app.listen(3000,()=>console.log('port3000'))
app.listen(3000, ()=> console.log('listen port 3000'))

const express = require('express')
const app = express()

app.get('/',(req,res)=>{

})
app.get('/',(req,res)=>{
    res.send('ok')
})

app.listen(3000, ()=> console.log('listening3000'))


const express = require('express')
const app = express()

app.get('/', (req,res)=>{
    res.send('ok')
} )
app.listen(3000,()=> console.log('lisenting port 3000') )




