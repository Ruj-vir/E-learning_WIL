const express = require('express')
const app = express()

app.get('/', (req, res) => {
    res.send('ok')
})

const arr = [
    {
        id: 1,
        name: 'meow'
    },
    {
        id: 3,
        name: 'meow3'
    }
]

    app.get('/cats/:id', (req, res) => {
        let paramitorID = +req.params.id
        const found = arr.find(function(el) {
            return el.id === paramitorID
        })
        console.log(found)
        if (found === undefined){
            res.sendStatus(404)
        }else{
            res.send(found)
        }
    })

app.get('/gg', (req, res) => {
    res.redirect('https://www.google.com/')
})

app.get('/cats', (req, res) => {
    res.send('hi cat')
})
app.get('*', (req, res) => {
    res.send('hello world')
})
app.listen(3000, () => console.log('listening port 3000'))