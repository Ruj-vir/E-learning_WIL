// const arr = [
//     {
//         id:1,
//         name: 'hi1'
//     },
//     {
//         id:2,
//         name: 'hi2'
//     },
//     {
//         id:3,
//         name: 'hi3'
//     },
//     {
//         id:4,
//         name: 'hi4'
//     }
// ]
// let No = 3
// let i = +No - 1
// const arrCom = arr[i]

// console.log(arrCom.id)
// console.log(arr)
// const found = arr.find(function(el){
//     return el.id %2 ===0
// })
// console.log(found)

// function add(x,y,callback){
//     result = x+y
//     return callback(result)
// }//  เขียนแบบ function ธรรมดา
// let addArrow=(x,y,callback)=>{
//     result = x+y
//     return callback(result)
// }// เขียนแบบ Arrow function 

// addArrow(2,7,console.log)
// add(1,7,console.log)

for(i = 1 ; i<41 ; i++){
    console.log('Sub000',i)
}