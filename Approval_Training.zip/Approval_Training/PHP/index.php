<?php
    include "server.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title>E-Approval_Course</title>
    <!-- css bootstrap -->
    <link rel="icon" href="img/icon/logo thaidaizo.png" type="image">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <!-- Js bootstrap -->
    <script src="assets/js/jQuery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>


</head>

<body>
    <div class="pos-f-t">
        <div class="collapse" id="navbarToggleExternalContent">
            <div class="bg-dark p-4">
                <h4 class="text-white">Collapsed content</h4>
                <span class="text-muted">Toggleable via the navbar brand.</span>
            </div>
        </div>
        <nav class="navbar navbar-dark bg-dark">
            <button class="navbar-toggler" type="button" data-toggle="collapse"
                data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </nav>
    </div>
    <!-- form inputs -->
    <form method="POST">
        <div class="form-group">
            <label for="exampleInputEmail1">Information Course Training</label>
            <input type="text" class="form-control" placeholder="Enter Course Name">
            <small id="emailHelp" class="form-text text-muted">Please input the information.</small>
        </div>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Accept and Check</label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</body>